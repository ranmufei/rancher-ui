'use strict';

define('ui/tests/admin-tab/accounts/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/accounts/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/accounts/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/accounts/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/accounts/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/accounts/index/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/accounts/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/accounts/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/accounts/index/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/accounts/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/accounts/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/accounts/new/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/accounts/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/accounts/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/accounts/new/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/accounts/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/accounts/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/accounts/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/audit-logs/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/audit-logs/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/audit-logs/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/audit-logs/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/audit-logs/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/audit-logs/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/activedirectory/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/activedirectory/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/activedirectory/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/activedirectory/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/activedirectory/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/activedirectory/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/azuread/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/azuread/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/azuread/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/azuread/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/azuread/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/azuread/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/github/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/github/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/github/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/github/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/github/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/github/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/index/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/localauth/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/localauth/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/localauth/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/localauth/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/localauth/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/localauth/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/openldap/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/openldap/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/openldap/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/openldap/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/openldap/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/openldap/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/shibboleth/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/shibboleth/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/shibboleth/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/auth/shibboleth/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/auth/shibboleth/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/auth/shibboleth/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/ha/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/ha/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/ha/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/ha/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/ha/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/ha/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/machine/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/machine/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/machine/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/machine/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/machine/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/machine/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/process/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/process/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/process/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/process/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/process/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/process/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/processes/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/processes/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/processes/index/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/processes/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/processes/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/processes/index/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/processes/list/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/processes/list/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/processes/list/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/processes/list/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/processes/list/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/processes/list/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/processes/pools/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/processes/pools/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/processes/pools/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/processes/pools/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/processes/pools/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/processes/pools/route.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/settings/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/settings/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/settings/controller.js should pass jshint.');
  });
});
define('ui/tests/admin-tab/settings/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | admin-tab/settings/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'admin-tab/settings/route.js should pass jshint.');
  });
});
define('ui/tests/app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'app.js should pass jshint.');
  });
});
define('ui/tests/application/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | application/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'application/controller.js should pass jshint.');
  });
});
define('ui/tests/application/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | application/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'application/route.js should pass jshint.');
  });
});
define('ui/tests/applications-tab/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | applications-tab/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'applications-tab/controller.js should pass jshint.');
  });
});
define('ui/tests/applications-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | applications-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'applications-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/applications-tab/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | applications-tab/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'applications-tab/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/dummy-dev/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/dummy-dev/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/dummy-dev/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/dummy-dev/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/dummy-dev/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/dummy-dev/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/index/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/hooks/edit-receiver/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/hooks/edit-receiver/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/hooks/edit-receiver/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/hooks/edit-receiver/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/hooks/edit-receiver/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/hooks/edit-receiver/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/hooks/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/hooks/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/hooks/index/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/hooks/new-receiver/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/hooks/new-receiver/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/hooks/new-receiver/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/hooks/new-receiver/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/hooks/new-receiver/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/hooks/new-receiver/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/hooks/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/hooks/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/hooks/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/keys/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/keys/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/keys/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/api/keys/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/api/keys/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/api/keys/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/help/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/help/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/help/controller.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/help/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/help/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/help/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/index/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/project/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/project/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/project/route.js should pass jshint.');
  });
});
define('ui/tests/authenticated/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | authenticated/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'authenticated/route.js should pass jshint.');
  });
});
define('ui/tests/backuptargets/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | backuptargets/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'backuptargets/controller.js should pass jshint.');
  });
});
define('ui/tests/backuptargets/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | backuptargets/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'backuptargets/index/controller.js should pass jshint.');
  });
});
define('ui/tests/backuptargets/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | backuptargets/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'backuptargets/index/route.js should pass jshint.');
  });
});
define('ui/tests/backuptargets/new-target/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | backuptargets/new-target/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'backuptargets/new-target/controller.js should pass jshint.');
  });
});
define('ui/tests/backuptargets/new-target/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | backuptargets/new-target/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'backuptargets/new-target/route.js should pass jshint.');
  });
});
define('ui/tests/backuptargets/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | backuptargets/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'backuptargets/route.js should pass jshint.');
  });
});
define('ui/tests/bulk-action-handler/service.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | bulk-action-handler/service.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'bulk-action-handler/service.js should pass jshint.');
  });
});
define('ui/tests/catalog-tab/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | catalog-tab/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'catalog-tab/controller.js should pass jshint.');
  });
});
define('ui/tests/catalog-tab/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | catalog-tab/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'catalog-tab/index/controller.js should pass jshint.');
  });
});
define('ui/tests/catalog-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | catalog-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'catalog-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/catalog-tab/launch/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | catalog-tab/launch/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'catalog-tab/launch/controller.js should pass jshint.');
  });
});
define('ui/tests/catalog-tab/launch/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | catalog-tab/launch/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'catalog-tab/launch/route.js should pass jshint.');
  });
});
define('ui/tests/catalog-tab/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | catalog-tab/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'catalog-tab/route.js should pass jshint.');
  });
});
define('ui/tests/certificates/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/controller.js should pass jshint.');
  });
});
define('ui/tests/certificates/detail/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/detail/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/detail/controller.js should pass jshint.');
  });
});
define('ui/tests/certificates/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/detail/route.js should pass jshint.');
  });
});
define('ui/tests/certificates/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/index/controller.js should pass jshint.');
  });
});
define('ui/tests/certificates/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/new/controller.js should pass jshint.');
  });
});
define('ui/tests/certificates/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/new/route.js should pass jshint.');
  });
});
define('ui/tests/certificates/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | certificates/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'certificates/route.js should pass jshint.');
  });
});
define('ui/tests/components/account-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/account-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/account-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/action-menu-item/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/action-menu-item/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/action-menu-item/component.js should pass jshint.');
  });
});
define('ui/tests/components/action-menu/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/action-menu/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/action-menu/component.js should pass jshint.');
  });
});
define('ui/tests/components/add-subpod/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/add-subpod/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/add-subpod/component.js should pass jshint.');
  });
});
define('ui/tests/components/advanced-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/advanced-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/advanced-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/api-field/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/api-field/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/api-field/component.js should pass jshint.');
  });
});
define('ui/tests/components/apikey-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/apikey-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/apikey-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/backups-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/backups-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/backups-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/badge-state/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/badge-state/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/badge-state/component.js should pass jshint.');
  });
});
define('ui/tests/components/catalog-box/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/catalog-box/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/catalog-box/component.js should pass jshint.');
  });
});
define('ui/tests/components/catalog-configure/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/catalog-configure/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/catalog-configure/component.js should pass jshint.');
  });
});
define('ui/tests/components/certificate-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/certificate-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/certificate-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/code-block/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/code-block/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/code-block/component.js should pass jshint.');
  });
});
define('ui/tests/components/columns-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/columns-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/columns-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/common-mark/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/common-mark/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/common-mark/component.js should pass jshint.');
  });
});
define('ui/tests/components/confirm-delete/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/confirm-delete/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/confirm-delete/component.js should pass jshint.');
  });
});
define('ui/tests/components/container-dot/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/container-dot/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/container-dot/component.js should pass jshint.');
  });
});
define('ui/tests/components/container-logs/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/container-logs/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/container-logs/component.js should pass jshint.');
  });
});
define('ui/tests/components/container-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/container-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/container-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/container-shell/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/container-shell/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/container-shell/component.js should pass jshint.');
  });
});
define('ui/tests/components/container-subpod/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/container-subpod/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/container-subpod/component.js should pass jshint.');
  });
});
define('ui/tests/components/copy-ip/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/copy-ip/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/copy-ip/component.js should pass jshint.');
  });
});
define('ui/tests/components/copy-to-clipboard/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/copy-to-clipboard/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/copy-to-clipboard/component.js should pass jshint.');
  });
});
define('ui/tests/components/device-permissions/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/device-permissions/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/device-permissions/component.js should pass jshint.');
  });
});
define('ui/tests/components/disk-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/disk-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/disk-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-account/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-account/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-account/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-aliasservice/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-aliasservice/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-aliasservice/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-apikey/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-apikey/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-apikey/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-certificate/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-certificate/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-certificate/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-container/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-container/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-container/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-externalservice/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-externalservice/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-externalservice/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-host/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-host/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-host/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-projecttemplate/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-projecttemplate/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-projecttemplate/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-registry/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-registry/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-registry/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-secret/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-secret/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-secret/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-service/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-service/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-service/component.js should pass jshint.');
  });
});
define('ui/tests/components/edit-stack/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/edit-stack/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-stack/component.js should pass jshint.');
  });
});
define('ui/tests/components/env-catalog/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/env-catalog/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/env-catalog/component.js should pass jshint.');
  });
});
define('ui/tests/components/environment-name/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/environment-name/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/environment-name/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-balancer-rules/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-balancer-rules/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-balancer-rules/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-command/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-command/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-command/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-container-links/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-container-links/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-container-links/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-disks/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-disks/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-disks/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-engine-opts/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-engine-opts/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-engine-opts/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-healthcheck/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-healthcheck/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-healthcheck/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-image/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-image/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-image/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-key-value/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-key-value/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-key-value/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-launch-config-switch/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-launch-config-switch/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-launch-config-switch/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-name-description/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-name-description/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-name-description/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-networking/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-networking/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-networking/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-ports/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-ports/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-ports/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-scale/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-scale/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-scale/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-scheduling/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-scheduling/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-scheduling/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-secrets/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-secrets/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-secrets/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-security/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-security/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-security/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-service-links/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-service-links/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-service-links/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-ssl-termination/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-ssl-termination/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-ssl-termination/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-stickiness/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-stickiness/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-stickiness/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-target-ip/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-target-ip/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-target-ip/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-target-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-target-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-target-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-targets/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-targets/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-targets/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-upgrade/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-upgrade/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-upgrade/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-user-labels/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-user-labels/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-user-labels/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-userdata/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-userdata/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-userdata/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-value-array/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-value-array/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-value-array/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-virtualmachine/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-virtualmachine/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-virtualmachine/component.js should pass jshint.');
  });
});
define('ui/tests/components/form-volumes/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/form-volumes/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/form-volumes/component.js should pass jshint.');
  });
});
define('ui/tests/components/header-state/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/header-state/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/header-state/component.js should pass jshint.');
  });
});
define('ui/tests/components/help-btn/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/help-btn/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/help-btn/component.js should pass jshint.');
  });
});
define('ui/tests/components/hero-add-service/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/hero-add-service/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/hero-add-service/component.js should pass jshint.');
  });
});
define('ui/tests/components/hook-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/hook-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/hook-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/host-pod/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/host-pod/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/host-pod/component.js should pass jshint.');
  });
});
define('ui/tests/components/host-settings/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/host-settings/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/host-settings/component.js should pass jshint.');
  });
});
define('ui/tests/components/identity-avatar/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/identity-avatar/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/identity-avatar/component.js should pass jshint.');
  });
});
define('ui/tests/components/identity-block/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/identity-block/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/identity-block/component.js should pass jshint.');
  });
});
define('ui/tests/components/info-multi-stats/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/info-multi-stats/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/info-multi-stats/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-certificate/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-certificate/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-certificate/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-command/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-command/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-command/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-identity/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-identity/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-identity/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-integer/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-integer/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-integer/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-or-display/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-or-display/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-or-display/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-paste/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-paste/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-paste/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-slider/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-slider/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-slider/component.js should pass jshint.');
  });
});
define('ui/tests/components/input-text-file/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/input-text-file/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/input-text-file/component.js should pass jshint.');
  });
});
define('ui/tests/components/labels-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/labels-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/labels-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/language-dropdown/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/language-dropdown/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/language-dropdown/component.js should pass jshint.');
  });
});
define('ui/tests/components/lb-addtl-info/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/lb-addtl-info/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/lb-addtl-info/component.js should pass jshint.');
  });
});
define('ui/tests/components/limit-parameters/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/limit-parameters/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/limit-parameters/component.js should pass jshint.');
  });
});
define('ui/tests/components/link-to-as-attrs/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/link-to-as-attrs/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/link-to-as-attrs/component.js should pass jshint.');
  });
});
define('ui/tests/components/login-github/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/login-github/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/login-github/component.js should pass jshint.');
  });
});
define('ui/tests/components/login-shibboleth/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/login-shibboleth/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/login-shibboleth/component.js should pass jshint.');
  });
});
define('ui/tests/components/login-user-pass/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/login-user-pass/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/login-user-pass/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-aliyunecs/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-aliyunecs/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-aliyunecs/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-amazonec2/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-amazonec2/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-amazonec2/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-azure/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-azure/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-azure/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-custom/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-custom/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-custom/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-digitalocean/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-digitalocean/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-digitalocean/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-exoscale/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-exoscale/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-exoscale/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-otc/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-otc/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-otc/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-other/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-other/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-other/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-packet/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-packet/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-packet/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-rackspace/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-rackspace/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-rackspace/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-ubiquity/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-ubiquity/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-ubiquity/component.js should pass jshint.');
  });
});
define('ui/tests/components/machine/driver-vmwarevsphere/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/machine/driver-vmwarevsphere/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/machine/driver-vmwarevsphere/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-about/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-about/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-about/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-auditlog-info/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-auditlog-info/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-auditlog-info/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-confirm-deactivate/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-confirm-deactivate/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-confirm-deactivate/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-console/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-console/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-console/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-container-logs/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-container-logs/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-container-logs/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-container-stop/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-container-stop/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-container-stop/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-edit-backup/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-edit-backup/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-edit-backup/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-edit-driver/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-edit-driver/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-edit-driver/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-edit-env-catalogs/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-edit-env-catalogs/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-edit-env-catalogs/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-edit-setting/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-edit-setting/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-edit-setting/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-edit-snapshot/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-edit-snapshot/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-edit-snapshot/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-feedback/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-feedback/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-feedback/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-host-evacuate/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-host-evacuate/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-host-evacuate/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-process-error/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-process-error/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-process-error/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-shell/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-shell/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-shell/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-wechat/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-wechat/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-wechat/component.js should pass jshint.');
  });
});
define('ui/tests/components/modal-welcome/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/modal-welcome/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/modal-welcome/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-aliasservice/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-aliasservice/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-aliasservice/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-balancer/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-balancer/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-balancer/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-catalog/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-catalog/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-catalog/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-container/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-container/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-container/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-externalservice/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-externalservice/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-externalservice/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-secret/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-secret/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-secret/component.js should pass jshint.');
  });
});
define('ui/tests/components/new-select/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/new-select/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/new-select/component.js should pass jshint.');
  });
});
define('ui/tests/components/orchestration/wait-kubernetes/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/orchestration/wait-kubernetes/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/orchestration/wait-kubernetes/component.js should pass jshint.');
  });
});
define('ui/tests/components/orchestration/wait-mesos/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/orchestration/wait-mesos/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/orchestration/wait-mesos/component.js should pass jshint.');
  });
});
define('ui/tests/components/orchestration/wait-swarm/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/orchestration/wait-swarm/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/orchestration/wait-swarm/component.js should pass jshint.');
  });
});
define('ui/tests/components/page-footer/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/page-footer/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/page-footer/component.js should pass jshint.');
  });
});
define('ui/tests/components/page-header-environment/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/page-header-environment/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/page-header-environment/component.js should pass jshint.');
  });
});
define('ui/tests/components/page-header-user/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/page-header-user/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/page-header-user/component.js should pass jshint.');
  });
});
define('ui/tests/components/page-header/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/page-header/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/page-header/component.js should pass jshint.');
  });
});
define('ui/tests/components/pretty-json/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/pretty-json/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/pretty-json/component.js should pass jshint.');
  });
});
define('ui/tests/components/process-execution-handler-rows/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/process-execution-handler-rows/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/process-execution-handler-rows/component.js should pass jshint.');
  });
});
define('ui/tests/components/process-execution-rows/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/process-execution-rows/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/process-execution-rows/component.js should pass jshint.');
  });
});
define('ui/tests/components/process-executions/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/process-executions/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/process-executions/component.js should pass jshint.');
  });
});
define('ui/tests/components/process-link/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/process-link/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/process-link/component.js should pass jshint.');
  });
});
define('ui/tests/components/progress-bar/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/progress-bar/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/progress-bar/component.js should pass jshint.');
  });
});
define('ui/tests/components/project-list/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/project-list/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/project-list/component.js should pass jshint.');
  });
});
define('ui/tests/components/project-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/project-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/project-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/project-template-list/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/project-template-list/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/project-template-list/component.js should pass jshint.');
  });
});
define('ui/tests/components/project-template-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/project-template-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/project-template-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/project-upgrade/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/project-upgrade/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/project-upgrade/component.js should pass jshint.');
  });
});
define('ui/tests/components/radio-button/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/radio-button/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/radio-button/component.js should pass jshint.');
  });
});
define('ui/tests/components/registry-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/registry-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/registry-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/save-cancel/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/save-cancel/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/save-cancel/component.js should pass jshint.');
  });
});
define('ui/tests/components/scheduling-rule-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/scheduling-rule-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/scheduling-rule-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-boolean/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-boolean/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-boolean/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-certificate/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-certificate/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-certificate/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-date/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-date/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-date/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-enum/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-enum/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-enum/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-float/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-float/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-float/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-int/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-int/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-int/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-masked/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-masked/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-masked/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-multiline/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-multiline/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-multiline/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-password/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-password/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-password/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-secret/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-secret/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-secret/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-service/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-service/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-service/component.js should pass jshint.');
  });
});
define('ui/tests/components/schema/input-string/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/schema/input-string/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/schema/input-string/component.js should pass jshint.');
  });
});
define('ui/tests/components/select-dot/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/select-dot/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/select-dot/component.js should pass jshint.');
  });
});
define('ui/tests/components/select-tab/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/select-tab/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/select-tab/component.js should pass jshint.');
  });
});
define('ui/tests/components/service-addtl-info/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/service-addtl-info/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/service-addtl-info/component.js should pass jshint.');
  });
});
define('ui/tests/components/settings/catalog-url/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/settings/catalog-url/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/settings/catalog-url/component.js should pass jshint.');
  });
});
define('ui/tests/components/settings/danger-zone/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/settings/danger-zone/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/settings/danger-zone/component.js should pass jshint.');
  });
});
define('ui/tests/components/settings/host-registration/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/settings/host-registration/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/settings/host-registration/component.js should pass jshint.');
  });
});
define('ui/tests/components/settings/telemetry-opt/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/settings/telemetry-opt/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/settings/telemetry-opt/component.js should pass jshint.');
  });
});
define('ui/tests/components/sidekick-addtl-info/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/sidekick-addtl-info/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/sidekick-addtl-info/component.js should pass jshint.');
  });
});
define('ui/tests/components/site-access/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/site-access/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/site-access/component.js should pass jshint.');
  });
});
define('ui/tests/components/snapshot-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/snapshot-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/snapshot-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/snapshot-timeline/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/snapshot-timeline/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/snapshot-timeline/component.js should pass jshint.');
  });
});
define('ui/tests/components/sortable-th/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/sortable-th/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/sortable-th/component.js should pass jshint.');
  });
});
define('ui/tests/components/spark-line/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/spark-line/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/spark-line/component.js should pass jshint.');
  });
});
define('ui/tests/components/stack-graph/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/stack-graph/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/stack-graph/component.js should pass jshint.');
  });
});
define('ui/tests/components/stack-header/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/stack-header/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/stack-header/component.js should pass jshint.');
  });
});
define('ui/tests/components/stack-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/stack-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/stack-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/storagepool-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/storagepool-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/storagepool-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/svg-edge/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/svg-edge/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/svg-edge/component.js should pass jshint.');
  });
});
define('ui/tests/components/svg-service-container/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/svg-service-container/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/svg-service-container/component.js should pass jshint.');
  });
});
define('ui/tests/components/svg-service-graph/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/svg-service-graph/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/svg-service-graph/component.js should pass jshint.');
  });
});
define('ui/tests/components/swarm/container-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/swarm/container-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/swarm/container-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/swarm/container-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/swarm/container-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/swarm/container-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/swarm/project-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/swarm/project-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/swarm/project-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/swarm/service-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/swarm/service-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/swarm/service-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/swarm/service-section/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/swarm/service-section/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/swarm/service-section/component.js should pass jshint.');
  });
});
define('ui/tests/components/textarea-autogrow/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/textarea-autogrow/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/textarea-autogrow/component.js should pass jshint.');
  });
});
define('ui/tests/components/theme-toggle/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/theme-toggle/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/theme-toggle/component.js should pass jshint.');
  });
});
define('ui/tests/components/tooltip-action-menu/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/tooltip-action-menu/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/tooltip-action-menu/component.js should pass jshint.');
  });
});
define('ui/tests/components/tooltip-basic/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/tooltip-basic/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/tooltip-basic/component.js should pass jshint.');
  });
});
define('ui/tests/components/tooltip-element/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/tooltip-element/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/tooltip-element/component.js should pass jshint.');
  });
});
define('ui/tests/components/tooltip-link/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/tooltip-link/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/tooltip-link/component.js should pass jshint.');
  });
});
define('ui/tests/components/tooltip-warning/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/tooltip-warning/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/tooltip-warning/component.js should pass jshint.');
  });
});
define('ui/tests/components/top-errors/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/top-errors/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/top-errors/component.js should pass jshint.');
  });
});
define('ui/tests/components/upgrade-btn/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/upgrade-btn/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/upgrade-btn/component.js should pass jshint.');
  });
});
define('ui/tests/components/upgrade-dropdown/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/upgrade-dropdown/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/upgrade-dropdown/component.js should pass jshint.');
  });
});
define('ui/tests/components/view-edit-project/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/view-edit-project/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/view-edit-project/component.js should pass jshint.');
  });
});
define('ui/tests/components/vm-console/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/vm-console/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/vm-console/component.js should pass jshint.');
  });
});
define('ui/tests/components/volume-row/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/volume-row/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/volume-row/component.js should pass jshint.');
  });
});
define('ui/tests/components/waiting-orchestration/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/waiting-orchestration/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/waiting-orchestration/component.js should pass jshint.');
  });
});
define('ui/tests/components/webhook/new-receiver/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/webhook/new-receiver/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/webhook/new-receiver/component.js should pass jshint.');
  });
});
define('ui/tests/components/webhook/scale-host-config/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/webhook/scale-host-config/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/webhook/scale-host-config/component.js should pass jshint.');
  });
});
define('ui/tests/components/webhook/scale-service-config/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/webhook/scale-service-config/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/webhook/scale-service-config/component.js should pass jshint.');
  });
});
define('ui/tests/components/webhook/service-upgrade-config/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | components/webhook/service-upgrade-config/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/webhook/service-upgrade-config/component.js should pass jshint.');
  });
});
define('ui/tests/console-vm/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | console-vm/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'console-vm/controller.js should pass jshint.');
  });
});
define('ui/tests/console-vm/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | console-vm/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'console-vm/route.js should pass jshint.');
  });
});
define('ui/tests/console/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | console/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'console/controller.js should pass jshint.');
  });
});
define('ui/tests/console/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | console/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'console/route.js should pass jshint.');
  });
});
define('ui/tests/container-log/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container-log/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container-log/controller.js should pass jshint.');
  });
});
define('ui/tests/container-log/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container-log/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container-log/route.js should pass jshint.');
  });
});
define('ui/tests/container/commands/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/commands/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/commands/route.js should pass jshint.');
  });
});
define('ui/tests/container/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/controller.js should pass jshint.');
  });
});
define('ui/tests/container/healthcheck/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/healthcheck/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/healthcheck/route.js should pass jshint.');
  });
});
define('ui/tests/container/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/index/route.js should pass jshint.');
  });
});
define('ui/tests/container/labels/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/labels/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/labels/route.js should pass jshint.');
  });
});
define('ui/tests/container/networking/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/networking/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/networking/route.js should pass jshint.');
  });
});
define('ui/tests/container/ports/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/ports/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/ports/route.js should pass jshint.');
  });
});
define('ui/tests/container/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/route.js should pass jshint.');
  });
});
define('ui/tests/container/scheduling/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/scheduling/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/scheduling/route.js should pass jshint.');
  });
});
define('ui/tests/container/security/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/security/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/security/route.js should pass jshint.');
  });
});
define('ui/tests/container/volumes/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | container/volumes/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'container/volumes/route.js should pass jshint.');
  });
});
define('ui/tests/containers/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | containers/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'containers/controller.js should pass jshint.');
  });
});
define('ui/tests/containers/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | containers/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'containers/index/controller.js should pass jshint.');
  });
});
define('ui/tests/containers/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | containers/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'containers/new/controller.js should pass jshint.');
  });
});
define('ui/tests/containers/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | containers/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'containers/new/route.js should pass jshint.');
  });
});
define('ui/tests/containers/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | containers/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'containers/route.js should pass jshint.');
  });
});
define('ui/tests/fail-whale/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | fail-whale/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'fail-whale/route.js should pass jshint.');
  });
});
define('ui/tests/formats.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | formats.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'formats.js should pass jshint.');
  });
});
define('ui/tests/helpers/array-includes.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/array-includes.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/array-includes.js should pass jshint.');
  });
});
define('ui/tests/helpers/auth-type.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/auth-type.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/auth-type.js should pass jshint.');
  });
});
define('ui/tests/helpers/concat-str.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/concat-str.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/concat-str.js should pass jshint.');
  });
});
define('ui/tests/helpers/date-calendar.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/date-calendar.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/date-calendar.js should pass jshint.');
  });
});
define('ui/tests/helpers/date-from-now.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/date-from-now.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/date-from-now.js should pass jshint.');
  });
});
define('ui/tests/helpers/date-recent.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/date-recent.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/date-recent.js should pass jshint.');
  });
});
define('ui/tests/helpers/date-str.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/date-str.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/date-str.js should pass jshint.');
  });
});
define('ui/tests/helpers/default-str.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/default-str.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/default-str.js should pass jshint.');
  });
});
define('ui/tests/helpers/destroy-app', ['exports', 'ember'], function (exports, _ember) {
  exports['default'] = destroyApp;

  function destroyApp(application) {
    _ember['default'].run(application, 'destroy');
  }
});
define('ui/tests/helpers/destroy-app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/destroy-app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/destroy-app.js should pass jshint.');
  });
});
define('ui/tests/helpers/ember-basic-dropdown', ['exports', 'ember', 'ember-runloop'], function (exports, _ember, _emberRunloop) {
  exports.nativeClick = nativeClick;
  exports.clickTrigger = clickTrigger;
  exports.tapTrigger = tapTrigger;
  exports.fireKeydown = fireKeydown;

  // integration helpers
  function focus(el) {
    if (!el) {
      return;
    }
    var $el = jQuery(el);
    if ($el.is(':input, [contenteditable=true]')) {
      var type = $el.prop('type');
      if (type !== 'checkbox' && type !== 'radio' && type !== 'hidden') {
        (0, _emberRunloop['default'])(null, function () {
          // Firefox does not trigger the `focusin` event if the window
          // does not have focus. If the document doesn't have focus just
          // use trigger('focusin') instead.

          if (!document.hasFocus || document.hasFocus()) {
            el.focus();
          } else {
            $el.trigger('focusin');
          }
        });
      }
    }
  }

  function nativeClick(selector) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    var mousedown = new window.Event('mousedown', { bubbles: true, cancelable: true, view: window });
    var mouseup = new window.Event('mouseup', { bubbles: true, cancelable: true, view: window });
    var click = new window.Event('click', { bubbles: true, cancelable: true, view: window });
    Object.keys(options).forEach(function (key) {
      mousedown[key] = options[key];
      mouseup[key] = options[key];
      click[key] = options[key];
    });
    var element = document.querySelector(selector);
    (0, _emberRunloop['default'])(function () {
      return element.dispatchEvent(mousedown);
    });
    focus(element);
    (0, _emberRunloop['default'])(function () {
      return element.dispatchEvent(mouseup);
    });
    (0, _emberRunloop['default'])(function () {
      return element.dispatchEvent(click);
    });
  }

  function clickTrigger(scope) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    var selector = '.ember-basic-dropdown-trigger';
    if (scope) {
      selector = scope + ' ' + selector;
    }
    nativeClick(selector, options);
  }

  function tapTrigger(scope) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    var selector = '.ember-basic-dropdown-trigger';
    if (scope) {
      selector = scope + ' ' + selector;
    }
    var touchStartEvent = new window.Event('touchstart', { bubbles: true, cancelable: true, view: window });
    Object.keys(options).forEach(function (key) {
      return touchStartEvent[key] = options[key];
    });
    (0, _emberRunloop['default'])(function () {
      return document.querySelector(selector).dispatchEvent(touchStartEvent);
    });
    var touchEndEvent = new window.Event('touchend', { bubbles: true, cancelable: true, view: window });
    Object.keys(options).forEach(function (key) {
      return touchEndEvent[key] = options[key];
    });
    (0, _emberRunloop['default'])(function () {
      return document.querySelector(selector).dispatchEvent(touchEndEvent);
    });
  }

  function fireKeydown(selector, k) {
    var oEvent = document.createEvent('Events');
    oEvent.initEvent('keydown', true, true);
    $.extend(oEvent, {
      view: window,
      ctrlKey: false,
      altKey: false,
      shiftKey: false,
      metaKey: false,
      keyCode: k,
      charCode: k
    });
    (0, _emberRunloop['default'])(function () {
      return document.querySelector(selector).dispatchEvent(oEvent);
    });
  }

  // acceptance helpers

  exports['default'] = function () {
    _ember['default'].Test.registerAsyncHelper('clickDropdown', function (app, cssPath) {
      var options = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      clickTrigger(cssPath, options);
    });

    _ember['default'].Test.registerAsyncHelper('tapDropdown', function (app, cssPath) {
      var options = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      tapTrigger(cssPath, options);
    });
  };
});
define('ui/tests/helpers/ember-power-select', ['exports', 'jquery', 'ember-runloop', 'ember-test'], function (exports, _jquery, _emberRunloop, _emberTest) {
  exports.nativeMouseDown = nativeMouseDown;
  exports.nativeMouseUp = nativeMouseUp;
  exports.triggerKeydown = triggerKeydown;
  exports.typeInSearch = typeInSearch;
  exports.clickTrigger = clickTrigger;
  exports.nativeTouch = nativeTouch;
  exports.touchTrigger = touchTrigger;

  // Helpers for integration tests

  function typeText(selector, text) {
    var $selector = (0, _jquery['default'])((0, _jquery['default'])(selector).get(0)); // Only interact with the first result
    $selector.val(text);
    var event = document.createEvent('Events');
    event.initEvent('input', true, true);
    $selector[0].dispatchEvent(event);
  }

  function fireNativeMouseEvent(eventType, selectorOrDomElement) {
    var options = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

    var event = new window.Event(eventType, { bubbles: true, cancelable: true, view: window });
    Object.keys(options).forEach(function (key) {
      return event[key] = options[key];
    });
    var target = undefined;
    if (typeof selectorOrDomElement === 'string') {
      target = (0, _jquery['default'])(selectorOrDomElement)[0];
    } else {
      target = selectorOrDomElement;
    }
    (0, _emberRunloop['default'])(function () {
      return target.dispatchEvent(event);
    });
  }

  function nativeMouseDown(selectorOrDomElement, options) {
    fireNativeMouseEvent('mousedown', selectorOrDomElement, options);
  }

  function nativeMouseUp(selectorOrDomElement, options) {
    fireNativeMouseEvent('mouseup', selectorOrDomElement, options);
  }

  function triggerKeydown(domElement, k) {
    var oEvent = document.createEvent('Events');
    oEvent.initEvent('keydown', true, true);
    _jquery['default'].extend(oEvent, {
      view: window,
      ctrlKey: false,
      altKey: false,
      shiftKey: false,
      metaKey: false,
      keyCode: k,
      charCode: k
    });
    (0, _emberRunloop['default'])(function () {
      domElement.dispatchEvent(oEvent);
    });
  }

  function typeInSearch(text) {
    (0, _emberRunloop['default'])(function () {
      typeText('.ember-power-select-search-input, .ember-power-select-search input, .ember-power-select-trigger-multiple-input, input[type="search"]', text);
    });
  }

  function clickTrigger(scope) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    var selector = '.ember-power-select-trigger';
    if (scope) {
      selector = scope + ' ' + selector;
    }
    nativeMouseDown(selector, options);
  }

  function nativeTouch(selectorOrDomElement) {
    var event = new window.Event('touchstart', { bubbles: true, cancelable: true, view: window });
    var target = undefined;

    if (typeof selectorOrDomElement === 'string') {
      target = (0, _jquery['default'])(selectorOrDomElement)[0];
    } else {
      target = selectorOrDomElement;
    }
    (0, _emberRunloop['default'])(function () {
      return target.dispatchEvent(event);
    });
    (0, _emberRunloop['default'])(function () {
      event = new window.Event('touchend', { bubbles: true, cancelable: true, view: window });
      target.dispatchEvent(event);
    });
  }

  function touchTrigger() {
    var selector = '.ember-power-select-trigger';
    nativeTouch(selector);
  }

  // Helpers for acceptance tests

  exports['default'] = function () {
    _emberTest['default'].registerAsyncHelper('selectChoose', function (app, cssPath, value) {
      var $trigger = find(cssPath + ' .ember-power-select-trigger');

      if ($trigger === undefined || $trigger.length === 0) {
        $trigger = find(cssPath);
      }

      var contentId = '' + $trigger.attr('aria-controls');
      var $content = find('#' + contentId);
      // If the dropdown is closed, open it
      if ($content.length === 0) {
        nativeMouseDown($trigger.get(0));
        wait();
      }

      // Select the option with the given text
      andThen(function () {
        var potentialTargets = (0, _jquery['default'])('#' + contentId + ' .ember-power-select-option:contains("' + value + '")').toArray();
        var target = undefined;
        if (potentialTargets.length > 1) {
          target = potentialTargets.filter(function (t) {
            return t.textContent.trim() === value;
          })[0] || potentialTargets[0];
        } else {
          target = potentialTargets[0];
        }
        nativeMouseUp(target);
      });
    });

    _emberTest['default'].registerAsyncHelper('selectSearch', function (app, cssPath, value) {
      var triggerPath = cssPath + ' .ember-power-select-trigger';
      var $trigger = find(triggerPath);
      if ($trigger === undefined || $trigger.length === 0) {
        triggerPath = cssPath;
        $trigger = find(triggerPath);
      }

      var contentId = '' + $trigger.attr('aria-controls');
      var isMultipleSelect = (0, _jquery['default'])(cssPath + ' .ember-power-select-trigger-multiple-input').length > 0;

      var dropdownIsClosed = (0, _jquery['default'])('#' + contentId).length === 0;
      if (dropdownIsClosed) {
        nativeMouseDown(triggerPath);
        wait();
      }
      var isDefaultSingleSelect = (0, _jquery['default'])('.ember-power-select-search-input').length > 0;

      if (isMultipleSelect) {
        fillIn(triggerPath + ' .ember-power-select-trigger-multiple-input', value);
      } else if (isDefaultSingleSelect) {
        fillIn('.ember-power-select-search-input', value);
      } else {
        // It's probably a customized version
        var inputIsInTrigger = !!find(cssPath + ' .ember-power-select-trigger input[type=search]')[0];
        if (inputIsInTrigger) {
          fillIn(triggerPath + ' input[type=search]', value);
        } else {
          fillIn('#' + contentId + ' .ember-power-select-search-input[type=search]', 'input');
        }
      }
    });

    _emberTest['default'].registerAsyncHelper('removeMultipleOption', function (app, cssPath, value) {
      var elem = find(cssPath + ' .ember-power-select-multiple-options > li:contains(' + value + ') > .ember-power-select-multiple-remove-btn').get(0);
      try {
        nativeMouseDown(elem);
        wait();
      } catch (e) {
        console.warn('css path to remove btn not found');
        throw e;
      }
    });

    _emberTest['default'].registerAsyncHelper('clearSelected', function (app, cssPath) {
      var elem = find(cssPath + ' .ember-power-select-clear-btn').get(0);
      try {
        nativeMouseDown(elem);
        wait();
      } catch (e) {
        console.warn('css path to clear btn not found');
        throw e;
      }
    });
  };
});
define('ui/tests/helpers/format-ip.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/format-ip.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/format-ip.js should pass jshint.');
  });
});
define('ui/tests/helpers/format-mib.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/format-mib.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/format-mib.js should pass jshint.');
  });
});
define('ui/tests/helpers/include.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/include.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/include.js should pass jshint.');
  });
});
define('ui/tests/helpers/is-last.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/is-last.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/is-last.js should pass jshint.');
  });
});
define('ui/tests/helpers/join-array.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/join-array.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/join-array.js should pass jshint.');
  });
});
define('ui/tests/helpers/lower-case.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/lower-case.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/lower-case.js should pass jshint.');
  });
});
define('ui/tests/helpers/module-for-acceptance', ['exports', 'qunit', 'ember', 'ui/tests/helpers/start-app', 'ui/tests/helpers/destroy-app'], function (exports, _qunit, _ember, _uiTestsHelpersStartApp, _uiTestsHelpersDestroyApp) {
  var Promise = _ember['default'].RSVP.Promise;

  exports['default'] = function (name) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    (0, _qunit.module)(name, {
      beforeEach: function beforeEach() {
        this.application = (0, _uiTestsHelpersStartApp['default'])();

        if (options.beforeEach) {
          return options.beforeEach.apply(this, arguments);
        }
      },

      afterEach: function afterEach() {
        var _this = this;

        var afterEach = options.afterEach && options.afterEach.apply(this, arguments);
        return Promise.resolve(afterEach).then(function () {
          return (0, _uiTestsHelpersDestroyApp['default'])(_this.application);
        });
      }
    });
  };
});
define('ui/tests/helpers/module-for-acceptance.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/module-for-acceptance.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/module-for-acceptance.js should pass jshint.');
  });
});
define('ui/tests/helpers/nl-to-br.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/nl-to-br.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/nl-to-br.js should pass jshint.');
  });
});
define('ui/tests/helpers/resolver', ['exports', 'ui/resolver', 'ui/config/environment'], function (exports, _uiResolver, _uiConfigEnvironment) {

  var resolver = _uiResolver['default'].create();

  resolver.namespace = {
    modulePrefix: _uiConfigEnvironment['default'].modulePrefix,
    podModulePrefix: _uiConfigEnvironment['default'].podModulePrefix
  };

  exports['default'] = resolver;
});
define('ui/tests/helpers/resolver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/resolver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/resolver.js should pass jshint.');
  });
});
define('ui/tests/helpers/run-time.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/run-time.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/run-time.js should pass jshint.');
  });
});
define('ui/tests/helpers/start-app', ['exports', 'ember', 'ui/app', 'ui/config/environment'], function (exports, _ember, _uiApp, _uiConfigEnvironment) {
  exports['default'] = startApp;

  function startApp(attrs) {
    var application = undefined;

    var attributes = _ember['default'].merge({}, _uiConfigEnvironment['default'].APP);
    attributes = _ember['default'].merge(attributes, attrs); // use defaults, but you can override;

    _ember['default'].run(function () {
      application = _uiApp['default'].create(attributes);
      application.setupForTesting();
      application.injectTestHelpers();
    });

    return application;
  }
});
define('ui/tests/helpers/start-app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/start-app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/start-app.js should pass jshint.');
  });
});
define('ui/tests/helpers/str-replace.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/str-replace.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/str-replace.js should pass jshint.');
  });
});
define('ui/tests/helpers/uc-first.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/uc-first.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/uc-first.js should pass jshint.');
  });
});
define('ui/tests/helpers/upper-case.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | helpers/upper-case.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/upper-case.js should pass jshint.');
  });
});
define('ui/tests/host/containers/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/containers/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/containers/controller.js should pass jshint.');
  });
});
define('ui/tests/host/containers/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/containers/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/containers/route.js should pass jshint.');
  });
});
define('ui/tests/host/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/controller.js should pass jshint.');
  });
});
define('ui/tests/host/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/index/route.js should pass jshint.');
  });
});
define('ui/tests/host/labels/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/labels/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/labels/route.js should pass jshint.');
  });
});
define('ui/tests/host/ports/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/ports/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/ports/controller.js should pass jshint.');
  });
});
define('ui/tests/host/ports/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/ports/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/ports/route.js should pass jshint.');
  });
});
define('ui/tests/host/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/route.js should pass jshint.');
  });
});
define('ui/tests/host/storage/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/storage/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/storage/controller.js should pass jshint.');
  });
});
define('ui/tests/host/storage/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | host/storage/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'host/storage/route.js should pass jshint.');
  });
});
define('ui/tests/hosts/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | hosts/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'hosts/controller.js should pass jshint.');
  });
});
define('ui/tests/hosts/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | hosts/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'hosts/index/controller.js should pass jshint.');
  });
});
define('ui/tests/hosts/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | hosts/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'hosts/index/route.js should pass jshint.');
  });
});
define('ui/tests/hosts/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | hosts/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'hosts/new/controller.js should pass jshint.');
  });
});
define('ui/tests/hosts/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | hosts/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'hosts/new/route.js should pass jshint.');
  });
});
define('ui/tests/hosts/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | hosts/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'hosts/route.js should pass jshint.');
  });
});
define('ui/tests/ie/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | ie/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'ie/controller.js should pass jshint.');
  });
});
define('ui/tests/infrastructure-tab/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | infrastructure-tab/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'infrastructure-tab/controller.js should pass jshint.');
  });
});
define('ui/tests/infrastructure-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | infrastructure-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'infrastructure-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/initializers/app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/app.js should pass jshint.');
  });
});
define('ui/tests/initializers/auth-store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/auth-store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/auth-store.js should pass jshint.');
  });
});
define('ui/tests/initializers/aws-sdk.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/aws-sdk.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/aws-sdk.js should pass jshint.');
  });
});
define('ui/tests/initializers/extend-bootstrap.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/extend-bootstrap.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/extend-bootstrap.js should pass jshint.');
  });
});
define('ui/tests/initializers/extend-ember-input.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/extend-ember-input.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/extend-ember-input.js should pass jshint.');
  });
});
define('ui/tests/initializers/extend-ember-link.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/extend-ember-link.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/extend-ember-link.js should pass jshint.');
  });
});
define('ui/tests/initializers/extend-ember-route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/extend-ember-route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/extend-ember-route.js should pass jshint.');
  });
});
define('ui/tests/initializers/extend-jquery.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/extend-jquery.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/extend-jquery.js should pass jshint.');
  });
});
define('ui/tests/initializers/extend-resource.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/extend-resource.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/extend-resource.js should pass jshint.');
  });
});
define('ui/tests/initializers/growl.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/growl.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/growl.js should pass jshint.');
  });
});
define('ui/tests/initializers/inject-application.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/inject-application.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/inject-application.js should pass jshint.');
  });
});
define('ui/tests/initializers/inject-router.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/inject-router.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/inject-router.js should pass jshint.');
  });
});
define('ui/tests/initializers/lookup.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/lookup.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/lookup.js should pass jshint.');
  });
});
define('ui/tests/initializers/polyfill-intl.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/polyfill-intl.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/polyfill-intl.js should pass jshint.');
  });
});
define('ui/tests/initializers/polyfill-svg.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/polyfill-svg.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/polyfill-svg.js should pass jshint.');
  });
});
define('ui/tests/initializers/resource-action-hover.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/resource-action-hover.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/resource-action-hover.js should pass jshint.');
  });
});
define('ui/tests/initializers/session.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/session.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/session.js should pass jshint.');
  });
});
define('ui/tests/initializers/touch.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/touch.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/touch.js should pass jshint.');
  });
});
define('ui/tests/initializers/user-store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/user-store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/user-store.js should pass jshint.');
  });
});
define('ui/tests/initializers/viewport.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/viewport.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/viewport.js should pass jshint.');
  });
});
define('ui/tests/initializers/webhook-store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | initializers/webhook-store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'initializers/webhook-store.js should pass jshint.');
  });
});
define('ui/tests/instance-initializers/auth-store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | instance-initializers/auth-store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'instance-initializers/auth-store.js should pass jshint.');
  });
});
define('ui/tests/instance-initializers/intl.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | instance-initializers/intl.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'instance-initializers/intl.js should pass jshint.');
  });
});
define('ui/tests/instance-initializers/store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | instance-initializers/store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'instance-initializers/store.js should pass jshint.');
  });
});
define('ui/tests/instance-initializers/theme.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | instance-initializers/theme.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'instance-initializers/theme.js should pass jshint.');
  });
});
define('ui/tests/instance-initializers/user-store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | instance-initializers/user-store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'instance-initializers/user-store.js should pass jshint.');
  });
});
define('ui/tests/instance-initializers/webhook-store.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | instance-initializers/webhook-store.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'instance-initializers/webhook-store.js should pass jshint.');
  });
});
define('ui/tests/integration/components/select-tab/component-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleForComponent)('select-tab', 'Integration | Component | select tab', {
    integration: true
  });

  (0, _emberQunit.test)('it renders', function (assert) {
    // Set any properties with this.set('myProperty', 'value');
    // Handle any actions with this.on('myAction', function(val) { ... });

    this.render(Ember.HTMLBars.template((function () {
      return {
        meta: {
          'revision': 'Ember@2.9.1',
          'loc': {
            'source': null,
            'start': {
              'line': 1,
              'column': 0
            },
            'end': {
              'line': 1,
              'column': 14
            }
          }
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment('');
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [['content', 'select-tab', ['loc', [null, [1, 0], [1, 14]]], 0, 0, 0, 0]],
        locals: [],
        templates: []
      };
    })()));

    assert.equal(this.$().text().trim(), '');

    // Template block usage:
    this.render(Ember.HTMLBars.template((function () {
      var child0 = (function () {
        return {
          meta: {
            'revision': 'Ember@2.9.1',
            'loc': {
              'source': null,
              'start': {
                'line': 2,
                'column': 4
              },
              'end': {
                'line': 4,
                'column': 4
              }
            }
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode('      template block text\n');
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();

      return {
        meta: {
          'revision': 'Ember@2.9.1',
          'loc': {
            'source': null,
            'start': {
              'line': 1,
              'column': 0
            },
            'end': {
              'line': 5,
              'column': 2
            }
          }
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode('\n');
          dom.appendChild(el0, el1);
          var el1 = dom.createComment('');
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode('  ');
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [['block', 'select-tab', [], [], 0, null, ['loc', [null, [2, 4], [4, 19]]]]],
        locals: [],
        templates: [child0]
      };
    })()));

    assert.equal(this.$().text().trim(), 'template block text');
  });
});
define('ui/tests/integration/components/select-tab/component-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | integration/components/select-tab/component-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/select-tab/component-test.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/controller.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/dashboard/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/dashboard/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/dashboard/controller.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/dashboard/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/dashboard/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/dashboard/route.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/kubectl/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/kubectl/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/kubectl/controller.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/kubectl/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/kubectl/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/kubectl/route.js should pass jshint.');
  });
});
define('ui/tests/k8s-tab/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | k8s-tab/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'k8s-tab/route.js should pass jshint.');
  });
});
define('ui/tests/loading/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | loading/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'loading/controller.js should pass jshint.');
  });
});
define('ui/tests/loading/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | loading/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'loading/route.js should pass jshint.');
  });
});
define('ui/tests/login/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | login/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'login/index/controller.js should pass jshint.');
  });
});
define('ui/tests/login/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | login/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'login/index/route.js should pass jshint.');
  });
});
define('ui/tests/login/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | login/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'login/route.js should pass jshint.');
  });
});
define('ui/tests/login/shibboleth-auth/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | login/shibboleth-auth/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'login/shibboleth-auth/route.js should pass jshint.');
  });
});
define('ui/tests/logout/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | logout/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'logout/route.js should pass jshint.');
  });
});
define('ui/tests/mesos-tab/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mesos-tab/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mesos-tab/index/controller.js should pass jshint.');
  });
});
define('ui/tests/mesos-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mesos-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mesos-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/mesos-tab/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mesos-tab/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mesos-tab/route.js should pass jshint.');
  });
});
define('ui/tests/mixins/cattle-polled-resource.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/cattle-polled-resource.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/cattle-polled-resource.js should pass jshint.');
  });
});
define('ui/tests/mixins/cattle-transitioning-resource.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/cattle-transitioning-resource.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/cattle-transitioning-resource.js should pass jshint.');
  });
});
define('ui/tests/mixins/console.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/console.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/console.js should pass jshint.');
  });
});
define('ui/tests/mixins/container-choices.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/container-choices.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/container-choices.js should pass jshint.');
  });
});
define('ui/tests/mixins/container-spark-stats.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/container-spark-stats.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/container-spark-stats.js should pass jshint.');
  });
});
define('ui/tests/mixins/driver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/driver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/driver.js should pass jshint.');
  });
});
define('ui/tests/mixins/filter-state.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/filter-state.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/filter-state.js should pass jshint.');
  });
});
define('ui/tests/mixins/grouped-instances.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/grouped-instances.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/grouped-instances.js should pass jshint.');
  });
});
define('ui/tests/mixins/hover-dropdowns.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/hover-dropdowns.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/hover-dropdowns.js should pass jshint.');
  });
});
define('ui/tests/mixins/intl-placeholder.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/intl-placeholder.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/intl-placeholder.js should pass jshint.');
  });
});
define('ui/tests/mixins/k8s-pod-selector.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/k8s-pod-selector.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/k8s-pod-selector.js should pass jshint.');
  });
});
define('ui/tests/mixins/manage-labels.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/manage-labels.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/manage-labels.js should pass jshint.');
  });
});
define('ui/tests/mixins/new-or-edit.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/new-or-edit.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/new-or-edit.js should pass jshint.');
  });
});
define('ui/tests/mixins/new-service-alias.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/new-service-alias.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/new-service-alias.js should pass jshint.');
  });
});
define('ui/tests/mixins/polled-model.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/polled-model.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/polled-model.js should pass jshint.');
  });
});
define('ui/tests/mixins/promise-to-cb.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/promise-to-cb.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/promise-to-cb.js should pass jshint.');
  });
});
define('ui/tests/mixins/safe-style.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/safe-style.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/safe-style.js should pass jshint.');
  });
});
define('ui/tests/mixins/select-tab.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/select-tab.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/select-tab.js should pass jshint.');
  });
});
define('ui/tests/mixins/sortable.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/sortable.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/sortable.js should pass jshint.');
  });
});
define('ui/tests/mixins/store-tweaks.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/store-tweaks.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/store-tweaks.js should pass jshint.');
  });
});
define('ui/tests/mixins/stripped-name.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/stripped-name.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/stripped-name.js should pass jshint.');
  });
});
define('ui/tests/mixins/subscribe.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/subscribe.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/subscribe.js should pass jshint.');
  });
});
define('ui/tests/mixins/throttled-resize.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/throttled-resize.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/throttled-resize.js should pass jshint.');
  });
});
define('ui/tests/mixins/tooltip.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/tooltip.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/tooltip.js should pass jshint.');
  });
});
define('ui/tests/mixins/upgrade-component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | mixins/upgrade-component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/upgrade-component.js should pass jshint.');
  });
});
define('ui/tests/models/account.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/account.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/account.js should pass jshint.');
  });
});
define('ui/tests/models/activesetting.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/activesetting.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/activesetting.js should pass jshint.');
  });
});
define('ui/tests/models/amazonec2config.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/amazonec2config.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/amazonec2config.js should pass jshint.');
  });
});
define('ui/tests/models/apikey.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/apikey.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/apikey.js should pass jshint.');
  });
});
define('ui/tests/models/auditlog.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/auditlog.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/auditlog.js should pass jshint.');
  });
});
define('ui/tests/models/backup.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/backup.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/backup.js should pass jshint.');
  });
});
define('ui/tests/models/backuptarget.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/backuptarget.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/backuptarget.js should pass jshint.');
  });
});
define('ui/tests/models/catalogtemplate.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/catalogtemplate.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/catalogtemplate.js should pass jshint.');
  });
});
define('ui/tests/models/certificate.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/certificate.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/certificate.js should pass jshint.');
  });
});
define('ui/tests/models/clustermembership.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/clustermembership.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/clustermembership.js should pass jshint.');
  });
});
define('ui/tests/models/composeproject.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/composeproject.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/composeproject.js should pass jshint.');
  });
});
define('ui/tests/models/container.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/container.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/container.js should pass jshint.');
  });
});
define('ui/tests/models/credential.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/credential.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/credential.js should pass jshint.');
  });
});
define('ui/tests/models/dnsservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/dnsservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/dnsservice.js should pass jshint.');
  });
});
define('ui/tests/models/externalservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/externalservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/externalservice.js should pass jshint.');
  });
});
define('ui/tests/models/githubconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/githubconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/githubconfig.js should pass jshint.');
  });
});
define('ui/tests/models/host.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/host.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/host.js should pass jshint.');
  });
});
define('ui/tests/models/identity.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/identity.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/identity.js should pass jshint.');
  });
});
define('ui/tests/models/image.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/image.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/image.js should pass jshint.');
  });
});
define('ui/tests/models/inservicestrategy.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/inservicestrategy.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/inservicestrategy.js should pass jshint.');
  });
});
define('ui/tests/models/instance.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/instance.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/instance.js should pass jshint.');
  });
});
define('ui/tests/models/kubernetesservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/kubernetesservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/kubernetesservice.js should pass jshint.');
  });
});
define('ui/tests/models/kubernetesstack.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/kubernetesstack.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/kubernetesstack.js should pass jshint.');
  });
});
define('ui/tests/models/launchconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/launchconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/launchconfig.js should pass jshint.');
  });
});
define('ui/tests/models/lbconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/lbconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/lbconfig.js should pass jshint.');
  });
});
define('ui/tests/models/ldapconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/ldapconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/ldapconfig.js should pass jshint.');
  });
});
define('ui/tests/models/loadbalancerservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/loadbalancerservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/loadbalancerservice.js should pass jshint.');
  });
});
define('ui/tests/models/localauthconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/localauthconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/localauthconfig.js should pass jshint.');
  });
});
define('ui/tests/models/machinedriver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/machinedriver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/machinedriver.js should pass jshint.');
  });
});
define('ui/tests/models/mountentry.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/mountentry.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/mountentry.js should pass jshint.');
  });
});
define('ui/tests/models/network.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/network.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/network.js should pass jshint.');
  });
});
define('ui/tests/models/networkdriverservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/networkdriverservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/networkdriverservice.js should pass jshint.');
  });
});
define('ui/tests/models/openldapconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/openldapconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/openldapconfig.js should pass jshint.');
  });
});
define('ui/tests/models/password.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/password.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/password.js should pass jshint.');
  });
});
define('ui/tests/models/port.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/port.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/port.js should pass jshint.');
  });
});
define('ui/tests/models/portrule.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/portrule.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/portrule.js should pass jshint.');
  });
});
define('ui/tests/models/processinstance.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/processinstance.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/processinstance.js should pass jshint.');
  });
});
define('ui/tests/models/processpool.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/processpool.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/processpool.js should pass jshint.');
  });
});
define('ui/tests/models/project.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/project.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/project.js should pass jshint.');
  });
});
define('ui/tests/models/projecttemplate.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/projecttemplate.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/projecttemplate.js should pass jshint.');
  });
});
define('ui/tests/models/receiver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/receiver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/receiver.js should pass jshint.');
  });
});
define('ui/tests/models/registrationtoken.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/registrationtoken.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/registrationtoken.js should pass jshint.');
  });
});
define('ui/tests/models/registry.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/registry.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/registry.js should pass jshint.');
  });
});
define('ui/tests/models/registrycredential.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/registrycredential.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/registrycredential.js should pass jshint.');
  });
});
define('ui/tests/models/scalehost.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/scalehost.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/scalehost.js should pass jshint.');
  });
});
define('ui/tests/models/scaleservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/scaleservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/scaleservice.js should pass jshint.');
  });
});
define('ui/tests/models/scalinggroup.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/scalinggroup.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/scalinggroup.js should pass jshint.');
  });
});
define('ui/tests/models/secondarylaunchconfig.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/secondarylaunchconfig.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/secondarylaunchconfig.js should pass jshint.');
  });
});
define('ui/tests/models/secret.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/secret.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/secret.js should pass jshint.');
  });
});
define('ui/tests/models/secretreference.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/secretreference.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/secretreference.js should pass jshint.');
  });
});
define('ui/tests/models/service.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/service.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/service.js should pass jshint.');
  });
});
define('ui/tests/models/servicelog.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/servicelog.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/servicelog.js should pass jshint.');
  });
});
define('ui/tests/models/serviceupgrade.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/serviceupgrade.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/serviceupgrade.js should pass jshint.');
  });
});
define('ui/tests/models/setting.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/setting.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/setting.js should pass jshint.');
  });
});
define('ui/tests/models/snapshot.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/snapshot.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/snapshot.js should pass jshint.');
  });
});
define('ui/tests/models/stack.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/stack.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/stack.js should pass jshint.');
  });
});
define('ui/tests/models/storagedriverservice.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/storagedriverservice.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/storagedriverservice.js should pass jshint.');
  });
});
define('ui/tests/models/storagepool.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/storagepool.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/storagepool.js should pass jshint.');
  });
});
define('ui/tests/models/template.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/template.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/template.js should pass jshint.');
  });
});
define('ui/tests/models/templateversion.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/templateversion.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/templateversion.js should pass jshint.');
  });
});
define('ui/tests/models/typedocumentation.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/typedocumentation.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/typedocumentation.js should pass jshint.');
  });
});
define('ui/tests/models/userpreference.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/userpreference.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/userpreference.js should pass jshint.');
  });
});
define('ui/tests/models/virtualmachine.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/virtualmachine.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/virtualmachine.js should pass jshint.');
  });
});
define('ui/tests/models/volume.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | models/volume.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/volume.js should pass jshint.');
  });
});
define('ui/tests/not-found/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | not-found/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'not-found/route.js should pass jshint.');
  });
});
define('ui/tests/registries/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | registries/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'registries/index/controller.js should pass jshint.');
  });
});
define('ui/tests/registries/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | registries/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'registries/index/route.js should pass jshint.');
  });
});
define('ui/tests/registries/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | registries/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'registries/new/controller.js should pass jshint.');
  });
});
define('ui/tests/registries/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | registries/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'registries/new/route.js should pass jshint.');
  });
});
define('ui/tests/registrycredential/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | registrycredential/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'registrycredential/controller.js should pass jshint.');
  });
});
define('ui/tests/resolver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | resolver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'resolver.js should pass jshint.');
  });
});
define('ui/tests/router.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | router.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'router.js should pass jshint.');
  });
});
define('ui/tests/routes/index.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | routes/index.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/index.js should pass jshint.');
  });
});
define('ui/tests/secrets/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | secrets/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'secrets/index/controller.js should pass jshint.');
  });
});
define('ui/tests/secrets/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | secrets/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'secrets/new/controller.js should pass jshint.');
  });
});
define('ui/tests/secrets/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | secrets/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'secrets/new/route.js should pass jshint.');
  });
});
define('ui/tests/secrets/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | secrets/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'secrets/route.js should pass jshint.');
  });
});
define('ui/tests/service/certificates/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/certificates/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/certificates/route.js should pass jshint.');
  });
});
define('ui/tests/service/containers/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/containers/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/containers/controller.js should pass jshint.');
  });
});
define('ui/tests/service/containers/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/containers/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/containers/route.js should pass jshint.');
  });
});
define('ui/tests/service/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/controller.js should pass jshint.');
  });
});
define('ui/tests/service/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/index/route.js should pass jshint.');
  });
});
define('ui/tests/service/labels/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/labels/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/labels/route.js should pass jshint.');
  });
});
define('ui/tests/service/links/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/links/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/links/route.js should pass jshint.');
  });
});
define('ui/tests/service/log/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/log/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/log/route.js should pass jshint.');
  });
});
define('ui/tests/service/new-alias/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-alias/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-alias/controller.js should pass jshint.');
  });
});
define('ui/tests/service/new-alias/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-alias/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-alias/route.js should pass jshint.');
  });
});
define('ui/tests/service/new-balancer/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-balancer/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-balancer/controller.js should pass jshint.');
  });
});
define('ui/tests/service/new-balancer/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-balancer/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-balancer/route.js should pass jshint.');
  });
});
define('ui/tests/service/new-external/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-external/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-external/controller.js should pass jshint.');
  });
});
define('ui/tests/service/new-external/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-external/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-external/route.js should pass jshint.');
  });
});
define('ui/tests/service/new-virtualmachine/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-virtualmachine/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-virtualmachine/controller.js should pass jshint.');
  });
});
define('ui/tests/service/new-virtualmachine/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new-virtualmachine/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new-virtualmachine/route.js should pass jshint.');
  });
});
define('ui/tests/service/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new/controller.js should pass jshint.');
  });
});
define('ui/tests/service/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/new/route.js should pass jshint.');
  });
});
define('ui/tests/service/port-rules/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/port-rules/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/port-rules/controller.js should pass jshint.');
  });
});
define('ui/tests/service/port-rules/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/port-rules/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/port-rules/route.js should pass jshint.');
  });
});
define('ui/tests/service/ports/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/ports/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/ports/route.js should pass jshint.');
  });
});
define('ui/tests/service/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | service/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'service/route.js should pass jshint.');
  });
});
define('ui/tests/services/access.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/access.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/access.js should pass jshint.');
  });
});
define('ui/tests/services/all-services.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/all-services.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/all-services.js should pass jshint.');
  });
});
define('ui/tests/services/catalog.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/catalog.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/catalog.js should pass jshint.');
  });
});
define('ui/tests/services/cookies.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/cookies.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/cookies.js should pass jshint.');
  });
});
define('ui/tests/services/endpoint.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/endpoint.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/endpoint.js should pass jshint.');
  });
});
define('ui/tests/services/github.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/github.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/github.js should pass jshint.');
  });
});
define('ui/tests/services/growl.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/growl.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/growl.js should pass jshint.');
  });
});
define('ui/tests/services/k8s.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/k8s.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/k8s.js should pass jshint.');
  });
});
define('ui/tests/services/mesos.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/mesos.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/mesos.js should pass jshint.');
  });
});
define('ui/tests/services/prefs.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/prefs.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/prefs.js should pass jshint.');
  });
});
define('ui/tests/services/projects.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/projects.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/projects.js should pass jshint.');
  });
});
define('ui/tests/services/resource-actions.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/resource-actions.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/resource-actions.js should pass jshint.');
  });
});
define('ui/tests/services/session.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/session.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/session.js should pass jshint.');
  });
});
define('ui/tests/services/settings.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/settings.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/settings.js should pass jshint.');
  });
});
define('ui/tests/services/shibboleth-auth.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/shibboleth-auth.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/shibboleth-auth.js should pass jshint.');
  });
});
define('ui/tests/services/store-reset.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/store-reset.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/store-reset.js should pass jshint.');
  });
});
define('ui/tests/services/swarm.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/swarm.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/swarm.js should pass jshint.');
  });
});
define('ui/tests/services/tab-session.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/tab-session.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/tab-session.js should pass jshint.');
  });
});
define('ui/tests/services/tooltip.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/tooltip.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/tooltip.js should pass jshint.');
  });
});
define('ui/tests/services/user-language.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/user-language.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/user-language.js should pass jshint.');
  });
});
define('ui/tests/services/user-theme.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | services/user-theme.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/user-theme.js should pass jshint.');
  });
});
define('ui/tests/settings/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/controller.js should pass jshint.');
  });
});
define('ui/tests/settings/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/index/route.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/detail/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/detail/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/detail/controller.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/detail/route.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/edit-template/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/edit-template/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/edit-template/route.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/index/controller.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/new-template/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/new-template/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/new-template/route.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/new/controller.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/new/route.js should pass jshint.');
  });
});
define('ui/tests/settings/projects/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | settings/projects/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'settings/projects/route.js should pass jshint.');
  });
});
define('ui/tests/stack/chart/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/chart/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/chart/controller.js should pass jshint.');
  });
});
define('ui/tests/stack/chart/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/chart/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/chart/route.js should pass jshint.');
  });
});
define('ui/tests/stack/code/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/code/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/code/controller.js should pass jshint.');
  });
});
define('ui/tests/stack/code/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/code/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/code/route.js should pass jshint.');
  });
});
define('ui/tests/stack/graph/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/graph/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/graph/controller.js should pass jshint.');
  });
});
define('ui/tests/stack/graph/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/graph/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/graph/route.js should pass jshint.');
  });
});
define('ui/tests/stack/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/index/controller.js should pass jshint.');
  });
});
define('ui/tests/stack/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/index/route.js should pass jshint.');
  });
});
define('ui/tests/stack/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stack/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stack/route.js should pass jshint.');
  });
});
define('ui/tests/stacks/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stacks/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stacks/controller.js should pass jshint.');
  });
});
define('ui/tests/stacks/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stacks/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stacks/index/controller.js should pass jshint.');
  });
});
define('ui/tests/stacks/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stacks/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stacks/index/route.js should pass jshint.');
  });
});
define('ui/tests/stacks/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stacks/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stacks/new/controller.js should pass jshint.');
  });
});
define('ui/tests/stacks/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stacks/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stacks/new/route.js should pass jshint.');
  });
});
define('ui/tests/stacks/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | stacks/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'stacks/route.js should pass jshint.');
  });
});
define('ui/tests/storagepools/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/controller.js should pass jshint.');
  });
});
define('ui/tests/storagepools/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/index/route.js should pass jshint.');
  });
});
define('ui/tests/storagepools/new-volume/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/new-volume/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/new-volume/controller.js should pass jshint.');
  });
});
define('ui/tests/storagepools/new-volume/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/new-volume/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/new-volume/route.js should pass jshint.');
  });
});
define('ui/tests/storagepools/pools/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/pools/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/pools/controller.js should pass jshint.');
  });
});
define('ui/tests/storagepools/pools/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/pools/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/pools/route.js should pass jshint.');
  });
});
define('ui/tests/storagepools/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | storagepools/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'storagepools/route.js should pass jshint.');
  });
});
define('ui/tests/swarm-tab/console/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | swarm-tab/console/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'swarm-tab/console/controller.js should pass jshint.');
  });
});
define('ui/tests/swarm-tab/console/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | swarm-tab/console/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'swarm-tab/console/route.js should pass jshint.');
  });
});
define('ui/tests/swarm-tab/dashboard/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | swarm-tab/dashboard/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'swarm-tab/dashboard/controller.js should pass jshint.');
  });
});
define('ui/tests/swarm-tab/dashboard/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | swarm-tab/dashboard/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'swarm-tab/dashboard/route.js should pass jshint.');
  });
});
define('ui/tests/swarm-tab/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | swarm-tab/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'swarm-tab/index/route.js should pass jshint.');
  });
});
define('ui/tests/swarm-tab/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | swarm-tab/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'swarm-tab/route.js should pass jshint.');
  });
});
define('ui/tests/test-helper', ['exports', 'ui/tests/helpers/resolver', 'ember-qunit'], function (exports, _uiTestsHelpersResolver, _emberQunit) {

  (0, _emberQunit.setResolver)(_uiTestsHelpersResolver['default']);
});
define('ui/tests/test-helper.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | test-helper.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'test-helper.js should pass jshint.');
  });
});
define('ui/tests/unit/backuptargets/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:backuptargets', 'Unit | Route | backuptargets', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/backuptargets/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/backuptargets/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/backuptargets/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/bulk-action-handler/service-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('service:bulk-action-handler', 'Unit | Service | bulk action handler', {
    // Specify the other units that are required for this test.
    // needs: ['service:foo']
  });

  // Replace this with your real tests.
  (0, _emberQunit.test)('it exists', function (assert) {
    var service = this.subject();
    assert.ok(service);
  });
});
define('ui/tests/unit/bulk-action-handler/service-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/bulk-action-handler/service-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/bulk-action-handler/service-test.js should pass jshint.');
  });
});
define('ui/tests/unit/container/labels/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:container/labels', 'Unit | Route | container/labels', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/container/labels/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/container/labels/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/container/labels/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/container/ports/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:container/ports', 'Unit | Route | container/ports', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/container/ports/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/container/ports/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/container/ports/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/container/volumes/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:container/volumes', 'Unit | Route | container/volumes', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/container/volumes/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/container/volumes/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/container/volumes/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/date-calendar-test', ['exports', 'ember-qunit', 'ui/helpers/date-calendar'], function (exports, _emberQunit, _uiHelpersDateCalendar) {

  (0, _emberQunit.moduleFor)('helper:date-calendar');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    var result = (0, _uiHelpersDateCalendar.dateCalendar)([42]);
    assert.ok(result);
  });
});
define('ui/tests/unit/helpers/date-calendar-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/date-calendar-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/date-calendar-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/date-from-now-test', ['exports', 'ember-qunit', 'ui/helpers/date-from-now'], function (exports, _emberQunit, _uiHelpersDateFromNow) {

  (0, _emberQunit.moduleFor)('helper:date-from-now');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    var result = (0, _uiHelpersDateFromNow.dateFromNow)([42]);
    assert.ok(result);
  });
});
define('ui/tests/unit/helpers/date-from-now-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/date-from-now-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/date-from-now-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/date-str-test', ['exports', 'ember-qunit', 'ui/helpers/date-str'], function (exports, _emberQunit, _uiHelpersDateStr) {

  (0, _emberQunit.moduleFor)('helper:date-str');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    var d = new Date('1982-02-24T18:42:00Z');
    var result = (0, _uiHelpersDateStr.dateStr)([d]);
    assert.ok(result);
  });

  (0, _emberQunit.test)('it takes format strings', function (assert) {
    var d = new Date('1982-02-24T18:42:00Z');
    var result = (0, _uiHelpersDateStr.dateStr)([d], { format: 'MMMM' });
    assert.equal(result, 'February');
  });
});
define('ui/tests/unit/helpers/date-str-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/date-str-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/date-str-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/lower-case-test', ['exports', 'ember-qunit', 'ui/helpers/lower-case'], function (exports, _emberQunit, _uiHelpersLowerCase) {

  (0, _emberQunit.moduleFor)('helper:lower-case');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works with strings', function (assert) {
    var result = (0, _uiHelpersLowerCase.lowerCase)(["HELLO"]);
    assert.ok(result === "hello");
  });
});
define('ui/tests/unit/helpers/lower-case-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/lower-case-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/lower-case-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/nl-to-br-test', ['exports', 'ember-qunit', 'ui/helpers/nl-to-br'], function (exports, _emberQunit, _uiHelpersNlToBr) {

  (0, _emberQunit.moduleFor)('helper:nl-to-br');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    var result = (0, _uiHelpersNlToBr.nlToBr)(["things\nstuff"]);
    assert.equal(result.toString(), "things<br/>\nstuff");
  });
});
define('ui/tests/unit/helpers/nl-to-br-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/nl-to-br-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/nl-to-br-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/run-time-test', ['exports', 'ui/helpers/run-time', 'qunit'], function (exports, _uiHelpersRunTime, _qunit) {

  (0, _qunit.module)('Unit | Helper | run time');

  // Replace this with your real tests.
  (0, _qunit.test)('it works', function (assert) {
    var result = (0, _uiHelpersRunTime.runTime)([42]);
    assert.ok(result);
  });
});
define('ui/tests/unit/helpers/run-time-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/run-time-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/run-time-test.js should pass jshint.');
  });
});
define('ui/tests/unit/helpers/upper-case-test', ['exports', 'ember-qunit', 'ui/helpers/upper-case'], function (exports, _emberQunit, _uiHelpersUpperCase) {

  (0, _emberQunit.moduleFor)('helper:upper-case');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works with strings', function (assert) {
    var result = (0, _uiHelpersUpperCase.upperCase)(["hello"]);
    assert.ok(result === "HELLO");
  });
});
define('ui/tests/unit/helpers/upper-case-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/helpers/upper-case-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/helpers/upper-case-test.js should pass jshint.');
  });
});
define('ui/tests/unit/initializers/extend-ember-input-test', ['exports', 'ember-qunit', 'ember', 'ui/initializers/extend-ember-input'], function (exports, _emberQunit, _ember, _uiInitializersExtendEmberInput) {

  var container, application;

  (0, _emberQunit.moduleFor)('initializer:extend-ember-input', {
    setup: function setup() {
      _ember['default'].run(function () {
        container = new _ember['default'].Container();
        application = _ember['default'].Application.create();
        application.deferReadiness();
      });
    }
  });

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    (0, _uiInitializersExtendEmberInput.initialize)(container, application);

    // you would normally confirm the results of the initializer here
    assert.ok(true);
  });
});
define('ui/tests/unit/initializers/extend-ember-input-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/initializers/extend-ember-input-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/initializers/extend-ember-input-test.js should pass jshint.');
  });
});
define('ui/tests/unit/initializers/touch-test', ['exports', 'ember-qunit', 'ember', 'ui/initializers/touch'], function (exports, _emberQunit, _ember, _uiInitializersTouch) {

  var container, application;

  (0, _emberQunit.moduleFor)('initializer:touch', {
    setup: function setup() {
      _ember['default'].run(function () {
        container = new _ember['default'].Container();
        application = _ember['default'].Application.create();
        application.deferReadiness();
      });
    }
  });

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    (0, _uiInitializersTouch.initialize)(container, application);

    // you would normally confirm the results of the initializer here
    assert.ok(true);
  });
});
define('ui/tests/unit/initializers/touch-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/initializers/touch-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/initializers/touch-test.js should pass jshint.');
  });
});
define('ui/tests/unit/pods/container/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:container', 'ContainerRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/pods/container/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/pods/container/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/pods/container/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/pods/hosts/controller-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('controller:hosts', 'HostsController', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  // Replace this with your real tests.
  (0, _emberQunit.test)('it exists', function (assert) {
    var controller = this.subject();
    assert.ok(controller);
  });
});
define('ui/tests/unit/pods/hosts/controller-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/pods/hosts/controller-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/pods/hosts/controller-test.js should pass jshint.');
  });
});
define('ui/tests/unit/pods/hosts/new/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:hosts/new', 'HostsNewRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/pods/hosts/new/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/pods/hosts/new/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/pods/hosts/new/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/pods/hosts/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:hosts', 'HostsRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/pods/hosts/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/pods/hosts/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/pods/hosts/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/pods/login/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:login/index', 'LoginRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/pods/login/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/pods/login/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/pods/login/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/pods/logout/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:logout', 'LogoutRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/pods/logout/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/pods/logout/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/pods/logout/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/routes/fail-whale-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:fail-whale', 'FailWhaleRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/routes/fail-whale-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/routes/fail-whale-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/fail-whale-test.js should pass jshint.');
  });
});
define('ui/tests/unit/routes/index-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:index', 'IndexRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/routes/index-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/routes/index-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/index-test.js should pass jshint.');
  });
});
define('ui/tests/unit/routes/loading-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:loading', 'LoadingRoute', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/routes/loading-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/routes/loading-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/loading-test.js should pass jshint.');
  });
});
define('ui/tests/unit/stack/chart/controller-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('controller:stack/chart', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  // Replace this with your real tests.
  (0, _emberQunit.test)('it exists', function (assert) {
    var controller = this.subject();
    assert.ok(controller);
  });
});
define('ui/tests/unit/stack/chart/controller-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/stack/chart/controller-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/stack/chart/controller-test.js should pass jshint.');
  });
});
define('ui/tests/unit/stack/chart/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:stack/chart', 'Unit | Route | stack/chart', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/stack/chart/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/stack/chart/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/stack/chart/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/storagepools/pools/route-test', ['exports', 'ember-qunit'], function (exports, _emberQunit) {

  (0, _emberQunit.moduleFor)('route:storagepools/pools', 'Unit | Route | storagepools/pools', {
    // Specify the other units that are required for this test.
    // needs: ['controller:foo']
  });

  (0, _emberQunit.test)('it exists', function (assert) {
    var route = this.subject();
    assert.ok(route);
  });
});
define('ui/tests/unit/storagepools/pools/route-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/storagepools/pools/route-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/storagepools/pools/route-test.js should pass jshint.');
  });
});
define('ui/tests/unit/utils/bootstrap-fixes-test', ['exports', 'ui/utils/bootstrap-fixes', 'qunit'], function (exports, _uiUtilsBootstrapFixes, _qunit) {

  (0, _qunit.module)('Unit | Utility | bootstrap fixes');

  // Replace this with your real tests.
  (0, _qunit.test)('it works', function (assert) {
    var result = _uiUtilsBootstrapFixes['default'].resizeDropdown;
    assert.ok(result);
  });
});
define('ui/tests/unit/utils/bootstrap-fixes-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/utils/bootstrap-fixes-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/utils/bootstrap-fixes-test.js should pass jshint.');
  });
});
define('ui/tests/unit/utils/parse-port-test', ['exports', 'ember', 'ui/utils/parse-port', 'qunit'], function (exports, _ember, _uiUtilsParsePort, _qunit) {

  (0, _qunit.module)('Unit | Utils | parse-port');

  var data = [{ str: '80', parsed: { host: '', hostIp: null, hostPort: null, container: 80, protocol: 'http' } }, { str: '80/tcp', parsed: { host: '', hostIp: null, hostPort: null, container: 80, protocol: 'tcp' } }, { str: '90:80', parsed: { host: '90', hostIp: null, hostPort: 90, container: 80, protocol: 'http' } }, { str: '90:80/http', parsed: { host: '90', hostIp: null, hostPort: 90, container: 80, protocol: 'http' }, expected: '90:80' }, { str: '1.2.3.4::80', parsed: { host: '1.2.3.4:', hostIp: '1.2.3.4', hostPort: null, container: 80, protocol: 'http' } }, { str: '1.2.3.4::80/tcp', parsed: { host: '1.2.3.4:', hostIp: '1.2.3.4', hostPort: null, container: 80, protocol: 'tcp' } }, { str: '1.2.3.4:90:80', parsed: { host: '1.2.3.4:90', hostIp: '1.2.3.4', hostPort: 90, container: 80, protocol: 'http' } }, { str: '1.2.3.4:90:80/tcp', parsed: { host: '1.2.3.4:90', hostIp: '1.2.3.4', hostPort: 90, container: 80, protocol: 'tcp' } }, { str: '[12:34:56::78]::80', parsed: { host: '[12:34:56::78]:', hostIp: '[12:34:56::78]', hostPort: null, container: 80, protocol: 'http' } }, { str: '[12:34:56::78]::80/tcp', parsed: { host: '[12:34:56::78]:', hostIp: '[12:34:56::78]', hostPort: null, container: 80, protocol: 'tcp' } }, { str: '[12:34:56::78]:90:80', parsed: { host: '[12:34:56::78]:90', hostIp: '[12:34:56::78]', hostPort: 90, container: 80, protocol: 'http' } }, { str: '[12:34:56::78]:90:80/tcp', parsed: { host: '[12:34:56::78]:90', hostIp: '[12:34:56::78]', hostPort: 90, container: 80, protocol: 'tcp' } }];

  data.forEach(function (obj) {
    var input = obj.str;
    var actual = (0, _uiUtilsParsePort.parsePortSpec)(input, 'http');

    if (obj.parsed) {
      (0, _qunit.test)('it can parse spec: ' + obj.str, function (assert) {
        var expected = obj.parsed;
        Object.keys(expected).forEach(function (key) {
          assert.strictEqual(_ember['default'].get(actual, key), _ember['default'].get(expected, key), key + ' parses correctly');
        });
      });

      (0, _qunit.test)('it can stringify spec: ' + obj.str, function (assert) {
        var input = obj.parsed;
        var expected = obj.expected || obj.str;
        var actual = (0, _uiUtilsParsePort.stringifyPortSpec)(input);
        assert.strictEqual(actual, expected, 'Objects are stringified correctly');
      });
    } else {
      (0, _qunit.test)("it can't parse spec: " + obj.str, function (assert) {
        assert.strictEqual(actual, null, 'Invalid data is not parseable');
      });
    }
  });

  data = [{ str: '', parsed: null }, { str: '80', parsed: { ip: null, port: 80 } }, { str: 'asdf', parsed: { ip: 'asdf', port: null } }, { str: '1.2.3.4', parsed: { ip: '1.2.3.4', port: null } }, { str: '1.2.3.4:80', parsed: { ip: '1.2.3.4', port: 80 } }, { str: '1.2.3.4:12ab', parsed: { ip: '1.2.3.4', port: null } }, { str: 'asdf:12ab', parsed: { ip: 'asdf', port: null } }, { str: '80asdf', parsed: { ip: '80asdf', port: null } }, { str: '12:34:56::78', parsed: { ip: '[12:34:56::78]', port: null } }, { str: '[12:34:56::78]', parsed: { ip: '[12:34:56::78]', port: null } }, { str: '[12:34:56::78]:80', parsed: { ip: '[12:34:56::78]', port: 80 } }, { str: '[12:34:56::78]:asdf', parsed: { ip: '[12:34:56::78]', port: null } }, { str: '[12:34:56::78]:90:ab', parsed: { ip: '[12:34:56::78]', port: null } }, { str: '2001:0db8:85a3:0000:0000:8a2e:0370:7334', parsed: { ip: '[2001:0db8:85a3:0000:0000:8a2e:0370:7334]', port: null } }, { str: '[2001:0db8:85a3:0000:0000:8a2e:0370:7334]:80', parsed: { ip: '[2001:0db8:85a3:0000:0000:8a2e:0370:7334]', port: 80 } }];

  data.forEach(function (obj) {
    var input = obj.str;
    var actual = (0, _uiUtilsParsePort.parseIpPort)(input);

    (0, _qunit.test)('it can parse: ' + obj.str, function (assert) {
      var expected = obj.parsed;

      if (expected === null) {
        assert.strictEqual(actual, null, input + ' cannot be parsed');
      } else {
        Object.keys(expected).forEach(function (key) {
          assert.strictEqual(_ember['default'].get(actual, key), _ember['default'].get(expected, key), key + ' parses correctly');
        });
      }
    });
  });
});
define('ui/tests/unit/utils/parse-port-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/utils/parse-port-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/utils/parse-port-test.js should pass jshint.');
  });
});
define('ui/tests/unit/utils/parse-target-test', ['exports', 'ember', 'ui/utils/parse-target', 'qunit'], function (exports, _ember, _uiUtilsParseTarget, _qunit) {

  (0, _qunit.module)('Unit | Utils | parse-target');

  var data = [
  // New Format
  { str: "example.com:80/path=81", parsed: { hostname: 'example.com', srcPort: 80, path: '/path', dstPort: 81 } }, { str: "example.com:80=81", parsed: { hostname: 'example.com', srcPort: 80, path: null, dstPort: 81 } }, { str: "example.com/path=81", parsed: { hostname: 'example.com', srcPort: null, path: '/path', dstPort: 81 } }, { str: "example.com=81", parsed: { hostname: 'example.com', srcPort: null, path: null, dstPort: 81 } }, { str: "80/path=81", parsed: { hostname: null, srcPort: 80, path: '/path', dstPort: 81 } }, { str: "80=81", parsed: { hostname: null, srcPort: 80, path: null, dstPort: 81 } }, { str: "/path=81", parsed: { hostname: null, srcPort: null, path: '/path', dstPort: 81 } }, { str: "81", parsed: { hostname: null, srcPort: null, path: null, dstPort: 81 } }, { str: "example.com:80/path", parsed: { hostname: 'example.com', srcPort: 80, path: '/path', dstPort: null } }, { str: "example.com:80", parsed: { hostname: 'example.com', srcPort: 80, path: null, dstPort: null } }, { str: "example.com/path", parsed: { hostname: 'example.com', srcPort: null, path: '/path', dstPort: null } }, { str: "example.com", parsed: { hostname: 'example.com', srcPort: null, path: null, dstPort: null } }, { str: "80/path", parsed: { hostname: null, srcPort: 80, path: '/path', dstPort: null } },
  //  {str: "80", Invalid, == dstPort   parsed: {hostname: null,          srcPort: 80,    path: null,     dstPort: null}},
  { str: "/path", parsed: { hostname: null, srcPort: null, path: '/path', dstPort: null } },
  //  {"", Invalid, but symmetry...     parsed: {hostname: null,          srcPort: null,  path: null,     dstPort: null}},
  //
  // Special case, numeric hostname
  { str: "1:2/3=4", parsed: { hostname: '1', srcPort: 2, path: '/3', dstPort: 4 } }, { str: "host3:7777", parsed: { hostname: 'host3', srcPort: 7777, path: null, dstPort: null } }, { str: "3host:7777", parsed: { hostname: '3host', srcPort: 7777, path: null, dstPort: null } },

  // Old format
  { str: "81:example.com/path", parsed: { hostname: 'example.com', srcPort: null, path: '/path', dstPort: 81 }, expected: "example.com/path=81" }, { str: "81:example.com", parsed: { hostname: 'example.com', srcPort: null, path: null, dstPort: 81 }, expected: "example.com=81" }, { str: "81:example.com:82", parsed: { hostname: 'example.com', srcPort: 82, path: null, dstPort: 81 }, expected: "example.com:82=81" }, { str: "81:example.com:82/path", parsed: { hostname: 'example.com', srcPort: 82, path: '/path', dstPort: 81 }, expected: "example.com:82/path=81" }, { str: "81:/path", parsed: { hostname: null, srcPort: null, path: '/path', dstPort: 81 }, expected: "/path=81" }];

  // Invalid
  //  {str: ":81",                         parsed: null},
  //  {str: "example.com::81",             parsed: null},
  data.forEach(function (obj) {
    var input = obj.str;
    var actual = (0, _uiUtilsParseTarget.parseTarget)(input);

    if (obj.parsed) {
      (0, _qunit.test)('it can parse: ' + obj.str, function (assert) {
        var expected = obj.parsed;
        Object.keys(expected).forEach(function (key) {
          assert.strictEqual(_ember['default'].get(actual, key), _ember['default'].get(expected, key), key + ' parses correctly');
        });
      });

      (0, _qunit.test)('it can stringify: ' + obj.str, function (assert) {
        var input = obj.parsed;
        var expected = obj.expected || obj.str;
        var actual = (0, _uiUtilsParseTarget.stringifyTarget)(input);
        assert.strictEqual(actual, expected, 'Objects are stringified correctly');
      });
    } else {
      (0, _qunit.test)("it can't parse: " + obj.str, function (assert) {
        assert.strictEqual(actual, null, 'Invalid data is not parseable');
      });
    }
  });
});
define('ui/tests/unit/utils/parse-target-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/utils/parse-target-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/utils/parse-target-test.js should pass jshint.');
  });
});
define('ui/tests/unit/utils/parse-version-test', ['exports', 'ui/utils/parse-version', 'qunit'], function (exports, _uiUtilsParseVersion, _qunit) {

  (0, _qunit.module)('Unit | Utils | parse-version');

  var data = [{ str: 'v1', parsed: ['1'], minor: 'v1.0' }, { str: 'v1.0', parsed: ['1', '0'], minor: 'v1.0' }, { str: 'v1.0.0', parsed: ['1', '0', '0'], minor: 'v1.0' }, { str: 'v1.1.0', parsed: ['1', '1', '0'], minor: 'v1.1' }, { str: 'v1.1.1', parsed: ['1', '1', '1'], minor: 'v1.1' }, { str: 'v1.0.0-foo', parsed: ['1', '0', '0', 'foo'], minor: 'v1.0' }, { str: 'v1.1.0-foo', parsed: ['1', '1', '0', 'foo'], minor: 'v1.1' }, { str: 'v1.0.0-pre1', parsed: ['1', '0', '0', 'pre1'], minor: 'v1.0' }, { str: 'v1.0.1-pre1', parsed: ['1', '0', '1', 'pre1'], minor: 'v1.0' }, { str: 'v1.1.0-pre1', parsed: ['1', '1', '0', 'pre1'], minor: 'v1.1' }, { str: 'v1.2.0-pre1', parsed: ['1', '2', '0', 'pre1'], minor: 'v1.2' }, { str: 'v1.2.1-pre1', parsed: ['1', '2', '1', 'pre1'], minor: 'v1.2' }, { str: 'v1.2.0-pre2', parsed: ['1', '2', '0', 'pre2'], minor: 'v1.2' }, { str: 'v1.2.0-pre2-rc1', parsed: ['1', '2', '0', 'pre2', 'rc1'], minor: 'v1.2' }, { str: 'v1.2.1-pre2-rc1', parsed: ['1', '2', '1', 'pre2', 'rc1'], minor: 'v1.2' }, { str: 'v1.2.1-pre2-rc2', parsed: ['1', '2', '1', 'pre2', 'rc2'], minor: 'v1.2' }];

  data.forEach(function (obj) {
    var input = obj.str;
    var actual = (0, _uiUtilsParseVersion.parse)(input);

    (0, _qunit.test)('it can parse: ' + obj.str, function (assert) {
      var expected = obj.parsed;
      assert.strictEqual(actual.length, expected.length, 'Parsed is the right length');
      assert.strictEqual(actual.join('#'), expected.join('#'), 'Strings are parsed correctly');
    });

    (0, _qunit.test)('it can minorVersion: ' + obj.str, function (assert) {
      var expected = obj.minor;
      var actual = (0, _uiUtilsParseVersion.minorVersion)(input);
      assert.strictEqual(actual, expected, 'Minors are minored correctly');
    });
  });
});
define('ui/tests/unit/utils/parse-version-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/utils/parse-version-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/utils/parse-version-test.js should pass jshint.');
  });
});
define('ui/tests/unit/utils/util-test', ['exports', 'ember-qunit', 'ui/utils/util'], function (exports, _emberQunit, _uiUtilsUtil) {

  (0, _emberQunit.moduleFor)('util:util');

  // Replace this with your real tests.
  (0, _emberQunit.test)('it works', function (assert) {
    var result = _uiUtilsUtil['default'].arrayDiff([1, 2, 3], [1, 2]);
    assert.equal(result.length, 1);
    assert.equal(result[0], 3);
  });
});
define('ui/tests/unit/utils/util-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/utils/util-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/utils/util-test.js should pass jshint.');
  });
});
define('ui/tests/unit/utils/validate-dns-test', ['exports', 'qunit', 'ui/utils/validate-dns'], function (exports, _qunit, _uiUtilsValidateDns) {

    (0, _qunit.module)('Unit | Utils | validate-dns');

    //test case
    var hostnames = [{ str: "aA0", result: true }, { str: "a", result: true },
    //chec for dot
    { str: ".aA0", result: false }, { str: "aA0.", result: true }, { str: "a.A0", result: true }, { str: "a..A0", result: false },
    //check for dash
    { str: "a-A0", result: true }, { str: "-aA0", result: false }, { str: "aA0-", result: false }, { str: "a--A0", result: false },
    //check for specifical character
    { str: "aA0/", result: false }, { str: "a/A0", result: false }, { str: "/aA0", result: false },
    //check for length
    { str: "", result: false }, { str: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900", result: true }, { str: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789000", result: false }, { str: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", result: true }, { str: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", result: false }];

    hostnames.forEach(function (element) {
        var input = element.str;
        var result = (0, _uiUtilsValidateDns.validateHostname)(input);
        (0, _qunit.test)("validating " + input, function (assert) {
            assert.strictEqual(result, element.result, 'validate correctly');
        });
    }, this);
});
define('ui/tests/unit/utils/validate-dns-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | unit/utils/validate-dns-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/utils/validate-dns-test.js should pass jshint.');
  });
});
define('ui/tests/utils/add-view-action.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/add-view-action.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/add-view-action.js should pass jshint.');
  });
});
define('ui/tests/utils/additional-routes.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/additional-routes.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/additional-routes.js should pass jshint.');
  });
});
define('ui/tests/utils/azure-choices.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/azure-choices.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/azure-choices.js should pass jshint.');
  });
});
define('ui/tests/utils/azure-vm-choices.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/azure-vm-choices.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/azure-vm-choices.js should pass jshint.');
  });
});
define('ui/tests/utils/bootstrap-fixes.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/bootstrap-fixes.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/bootstrap-fixes.js should pass jshint.');
  });
});
define('ui/tests/utils/browser-storage.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/browser-storage.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/browser-storage.js should pass jshint.');
  });
});
define('ui/tests/utils/constants.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/constants.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/constants.js should pass jshint.');
  });
});
define('ui/tests/utils/debounce.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/debounce.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/debounce.js should pass jshint.');
  });
});
define('ui/tests/utils/errors.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/errors.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/errors.js should pass jshint.');
  });
});
define('ui/tests/utils/filtered-sorted-array-proxy.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/filtered-sorted-array-proxy.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/filtered-sorted-array-proxy.js should pass jshint.');
  });
});
define('ui/tests/utils/intl/missing-message.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/intl/missing-message.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/intl/missing-message.js should pass jshint.');
  });
});
define('ui/tests/utils/load-script.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/load-script.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/load-script.js should pass jshint.');
  });
});
define('ui/tests/utils/multi-stats.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/multi-stats.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/multi-stats.js should pass jshint.');
  });
});
define('ui/tests/utils/navigation-tree.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/navigation-tree.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/navigation-tree.js should pass jshint.');
  });
});
define('ui/tests/utils/packet-choices.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/packet-choices.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/packet-choices.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-catalog-setting.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-catalog-setting.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-catalog-setting.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-externalid.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-externalid.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-externalid.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-healthcheck.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-healthcheck.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-healthcheck.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-port.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-port.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-port.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-target.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-target.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-target.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-uri.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-uri.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-uri.js should pass jshint.');
  });
});
define('ui/tests/utils/parse-version.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/parse-version.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/parse-version.js should pass jshint.');
  });
});
define('ui/tests/utils/platform.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/platform.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/platform.js should pass jshint.');
  });
});
define('ui/tests/utils/rackspace-choices.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/rackspace-choices.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/rackspace-choices.js should pass jshint.');
  });
});
define('ui/tests/utils/socket.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/socket.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/socket.js should pass jshint.');
  });
});
define('ui/tests/utils/sort.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/sort.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/sort.js should pass jshint.');
  });
});
define('ui/tests/utils/util.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/util.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/util.js should pass jshint.');
  });
});
define('ui/tests/utils/validate-dns.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/validate-dns.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/validate-dns.js should pass jshint.');
  });
});
define('ui/tests/utils/xterm-fit-addon.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | utils/xterm-fit-addon.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/xterm-fit-addon.js should pass jshint.');
  });
});
define('ui/tests/virtualmachine/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachine/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachine/controller.js should pass jshint.');
  });
});
define('ui/tests/virtualmachine/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachine/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachine/index/route.js should pass jshint.');
  });
});
define('ui/tests/virtualmachine/labels/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachine/labels/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachine/labels/route.js should pass jshint.');
  });
});
define('ui/tests/virtualmachine/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachine/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachine/route.js should pass jshint.');
  });
});
define('ui/tests/virtualmachines/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachines/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachines/controller.js should pass jshint.');
  });
});
define('ui/tests/virtualmachines/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachines/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachines/index/controller.js should pass jshint.');
  });
});
define('ui/tests/virtualmachines/new/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachines/new/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachines/new/controller.js should pass jshint.');
  });
});
define('ui/tests/virtualmachines/new/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachines/new/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachines/new/route.js should pass jshint.');
  });
});
define('ui/tests/virtualmachines/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | virtualmachines/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'virtualmachines/route.js should pass jshint.');
  });
});
define('ui/tests/vm-log/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | vm-log/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'vm-log/controller.js should pass jshint.');
  });
});
define('ui/tests/vm-log/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint | vm-log/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'vm-log/route.js should pass jshint.');
  });
});
/* jshint ignore:start */

require('ui/tests/test-helper');
EmberENV.TESTS_FILE_LOADED = true;

/* jshint ignore:end */
//# sourceMappingURL=tests.map
